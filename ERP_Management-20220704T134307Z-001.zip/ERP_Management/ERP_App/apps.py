from django.apps import AppConfig


class ErpAppConfig(AppConfig):
    name = 'ERP_App'
